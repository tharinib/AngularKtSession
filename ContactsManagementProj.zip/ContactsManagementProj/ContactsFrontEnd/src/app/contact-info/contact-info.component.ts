import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Contact } from '../models/contact';
import { ContactsService } from '../services/contactsService';

@Component({
  selector: 'app-contact-info',
  templateUrl: './contact-info.component.html',
  styleUrls: ['./contact-info.component.css']
})
export class ContactInfoComponent implements OnInit {
  contact:Contact;

  constructor(private route: ActivatedRoute,
    private contactsService:ContactsService) { }

  ngOnInit() {
    this.route.params.subscribe(
      (params)=>{
        let contactId =params.id;
        if(contactId){
          this.contactsService.getContactById(contactId).subscribe(
            (data)=>{
              this.contact=data;
            }
          );
        }
      }
    );
  }

}
