export class Contact {
    contactId:number;
    firstName:string;
    lastName:string;
    mobile:number;
    mail:string;
    dateOfBirth:string;
    gender:string;
    group:string;
}