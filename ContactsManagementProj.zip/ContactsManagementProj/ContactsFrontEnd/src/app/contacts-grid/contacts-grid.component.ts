import { Component, OnInit } from '@angular/core';
import { Contact } from '../models/contact';
import { ContactsService } from '../services/contactsService';

@Component({
  selector: 'app-contacts-grid',
  templateUrl: './contacts-grid.component.html',
  styleUrls: ['./contacts-grid.component.css']
})
export class ContactsGridComponent implements OnInit {

  contacts :Contact [];

  constructor(private contactsService:ContactsService) { }

  ngOnInit() {
    this.contactsService.getContacts().subscribe(
      (data) =>{
        this.contacts=data;
      }
    );
  }

}
