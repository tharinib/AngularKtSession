import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

import { AppComponent } from './app.component';
import { BannerComponent } from './banner/banner.component';
import { HeaderComponent } from './header/header.component';
import { AppRoutingModule } from './app-routing.module';
import { ContactsComponent } from './contacts/contacts.component';
import { ContactInfoComponent } from './contact-info/contact-info.component';
import { ContactsGridComponent } from './contacts-grid/contacts-grid.component';
import { ContactsListComponent } from './contacts-list/contacts-list.component';
import { DeleteContactComponent } from './delete-contact/delete-contact.component';
import { ContactCountPipe } from './contactCount.pipe';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ContactFormComponent } from './contact-form/contact-form.component';

@NgModule({
  declarations: [
    AppComponent,
    BannerComponent,
    HeaderComponent,
    ContactsComponent,
    ContactInfoComponent,
    ContactsGridComponent,
    ContactsListComponent,
    DeleteContactComponent,
    ContactCountPipe,
    DashboardComponent,
    ContactFormComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
