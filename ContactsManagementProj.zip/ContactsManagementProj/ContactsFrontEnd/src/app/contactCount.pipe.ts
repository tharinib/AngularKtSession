import { Pipe, PipeTransform } from '@angular/core';
import { Contact } from './models/contact';

@Pipe({
  name: 'contactCount'
})
export class ContactCountPipe implements PipeTransform {

  transform(value: Contact[], field?: string, fieldValue?: string): number {
    let result = 0;

    if (value) {
      if (!field) {
        result = value.length;
      } else if (field.toLowerCase() == 'dateofbirth') {
        let todayDate = new Date();
        value.forEach(item => {
          let dob = new Date(item.dateOfBirth);
          if (dob.getDate() == todayDate.getDate() && dob.getMonth() == todayDate.getMonth()) {
            result++;
          }
        });
      } else if (field.toLowerCase() == 'gender') {
        value.forEach(item => {
          if (item.gender.toLowerCase() == fieldValue.toLowerCase()) {
            result++;
          }
        });
      } else if (field.toLowerCase() == 'group') {
        value.forEach(item => {
          if (item.group.toLowerCase() == fieldValue.toLowerCase()) {
            result++;
          }
        });
      }
    }
    return result;
  }

}
