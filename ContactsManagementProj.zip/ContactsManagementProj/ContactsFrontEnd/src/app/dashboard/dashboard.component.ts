import { Component, OnInit } from '@angular/core';
import { Contact } from '../models/contact';
import { ContactsService } from '../services/contactsService';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  contacts :Contact [];
  constructor(private contactsService:ContactsService) { }

  ngOnInit() {
    this.contactsService.getContacts().subscribe(
      (data)=>{
        this.contacts=data;
      }
    );
  }

}
