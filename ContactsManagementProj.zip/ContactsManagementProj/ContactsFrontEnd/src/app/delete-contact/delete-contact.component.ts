import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Contact } from '../models/contact';
import { ContactsService } from '../services/contactsService';

@Component({
  selector: 'app-delete-contact',
  templateUrl: './delete-contact.component.html',
  styleUrls: ['./delete-contact.component.css']
})
export class DeleteContactComponent implements OnInit {
  contactId : number;

  constructor( private route: ActivatedRoute,
    private contactsService: ContactsService,
    private router:Router) { }

  ngOnInit() {
    this.route.params.subscribe(
      (params)=>{
        this.contactId=params.id;
      }
    );
  }

  delete(){
    this.contactsService.deleteById(this.contactId).subscribe(
      (resp)=>{
        this.router.navigateByUrl("/");
      }
    );
  }

}
