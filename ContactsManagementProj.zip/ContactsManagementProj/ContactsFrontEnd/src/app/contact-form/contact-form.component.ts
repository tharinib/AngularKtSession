import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Contact } from '../models/contact';
import { ContactsService } from '../services/contactsService';

@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.css']
})
export class ContactFormComponent implements OnInit {

  contact:Contact;
  isNew:boolean;

  constructor(
    private route:ActivatedRoute,
    private contactsService:ContactsService,
    private router:Router
  ) { }

  ngOnInit() {
    this.route.params.subscribe(
      (params)=>{
        let contactId = params.id;
        if(contactId){
          this.contactsService.getContactById(contactId).subscribe(
            (data)=>{
              this.contact=data;
              this.isNew=false;
            }
          );
        }else{
          this.contact=new Contact();
          this.isNew=true;
        }
      }
    );
  }

  handleFormSubmition(){
    if(this.isNew){
      console.log(this.contact.dateOfBirth);
      this.contactsService.addContact(this.contact).subscribe(
        (resp) =>{
          this.router.navigateByUrl("/");
        }
      );
    }else{
      this.contactsService.saveContact(this.contact).subscribe(
        (resp) =>{
          this.router.navigateByUrl("/");
        }
      );
    }
  }

}
