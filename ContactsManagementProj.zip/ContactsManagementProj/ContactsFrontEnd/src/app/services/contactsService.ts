import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Contact } from '../models/contact';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContactsService {

  private apiUrl:string;

  constructor(private http : HttpClient) {
    this.apiUrl="http://localhost:5000/contacts";
  }

  getContacts(): Observable<Contact[]> {
    return this.http.get<Contact[]>(this.apiUrl);
  }

  getContactById(id: number): Observable<Contact> {
    return this.http.get<Contact>(`${this.apiUrl}/${id}`);
  }

  addContact(contact: Contact): Observable<Response> {
    return this.http.post<Response>(this.apiUrl,contact);
  }

  saveContact(contact: Contact): Observable<Response> {
    return this.http.put<Response>(this.apiUrl,contact);
  }

  deleteById(id: number): Observable<Response> {
    return this.http.delete<Response>(`${this.apiUrl}/${id}`);
  }
}