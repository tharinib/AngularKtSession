let express = require('express');

let bp = require('body-parser');

let cors = require('cors');

let fs = require('fs');

 

const dataFile = "./contacts.json";

const port = 5000;

let contactsData = null;

 

fs.readFile(dataFile,(err,data)=>{

    if(err){

        console.log(err);

    }else{

        contactsData = JSON.parse(data);

    }

});

 

const saveDataAndRespond = (resp) =>{

    fs.writeFile(dataFile,JSON.stringify(contactsData),(err)=>{

        if(err){

            console.log(err);

            resp.status(500); //internal server error

            resp.end();

        }else{

            resp.status(200); //ok

            resp.end();

        }

    });

};

 

const parseRequestToContact = (req)=>( 

    {

        contactId: req.body.contactId,

        firstName: req.body.firstName,

        lastName: req.body.lastName,

        mobile: req.body.mobile,

        mail: req.body.mail,

        dateOfBirth: req.body.dateOfBirth,

        gender: req.body.gender,

        group: req.body.group,

    }

);

 

let libServer = express();

libServer.use(bp.json());

libServer.use(bp.urlencoded({extended:true}));

libServer.use(cors());

 

//default get request handler

libServer.get('/',(req,resp)=>{

    resp.send("Welcome To Contacts Server...!");

});

//a get request handler to the url /contacts that returns the contacts list

libServer.get('/contacts',(req,resp)=>{

    resp.send(contactsData.contacts);

});

 

//a get request handler to the url /contacts/contactId that returns the contact with that id

libServer.get('/contacts/:id',(req,resp)=>{

    let contact = contactsData.contacts.find(b=>b.contactId==req.params.id);

    if(contact){

        resp.send(contact);

    }else{

        resp.status(404); //NOT FOUND

        resp.end();

    }

});

 

//a post request handler to the url /contacts

libServer.post('/contacts',(req,resp)=>{

    let contact = parseRequestToContact(req);

    contactsData.contacts.push(contact);

    saveDataAndRespond(resp);

});

//a put request handler to the url /contacts

libServer.put('/contacts',(req,resp)=>{

    let contact = parseRequestToContact(req);

    let index = contactsData.books.findIndex(b=>b.contactId==contact.contactId);

    contactsData.contacts[index]=contact;

    saveDataAndRespond(resp);

});

 

//a delete request handler to the url /contacts/:contactId

libServer.delete('/contacts/:id',(req,resp)=>{

    let index = contactsData.contacts.findIndex(b=>b.contactId==req.param.id);

    contactsData.contacts.splice(index,1);

    saveDataAndRespond(resp);

});

libServer.listen(port,()=>{

    console.log(`Server is ready at ${port}`)

});